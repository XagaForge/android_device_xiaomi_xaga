#!/bin/bash

clear
SCRIPT_PATH=$(dirname "$(readlink -f "$0")")
fastboot="${SCRIPT_PATH}/tools/linux/fastboot"
imagesPath="${SCRIPT_PATH}/images"

# Check if fastboot exists and is executable
if [ ! -f "$fastboot" ]; then
    echo "\"$fastboot\" not found."
    exit
fi

if [ ! -x "$fastboot" ]; then
    chmod +x "$fastboot"
    if [ $? -ne 0 ]; then
        echo "\"$fastboot\" cannot be executed."
        exit
    fi
fi

echo
echo "Do you want to format data? (Y/N)"
read -rp "" formatData

if [[ "$formatData" =~ ^[Yy]$ ]]; then
    echo "Formatting data..."
    "$fastboot" erase metadata
    "$fastboot" erase userdata
else
    echo "Skipping data formatting."
fi


cd "$imagesPath" || exit
echo "Verifying critical images..."
if [ ! -f "boot.img" ]; then
    echo "boot.img is missing. Aborting."
    read -rp "Press any key to exit the script..." -n1 -s
    exit
fi
if [ ! -f "vendor_boot.img" ]; then
    echo "vendor_boot.img is missing. Aborting."
    read -rp "Press any key to exit the script..." -n1 -s
    exit
fi

# Verifying the existence of additional images
echo "Verifying additional images..."

# List of required images
requiredImages=(
    "apusys.img" "audio_dsp.img" "boot.img" "ccu.img" "dpm.img" "dtbo.img" "gpueb.img"
    "gz.img" "lk.img" "mcf_ota.img" "mcupm.img" "md1img.img" "mvpu_algo.img"
    "pi_img.img" "scp.img" "spmfw.img" "sspm.img" "tee.img"
    "vcp.img" "vbmeta.img" "vendor_boot.img" "vbmeta_system.img" "vbmeta_vendor.img"
)

# Additional required files
additionalRequiredFiles=(
    "super.img" "preloader_xaga.bin"
)

# Check for missing images
missingImages=()

for img in "${requiredImages[@]}" "${additionalRequiredFiles[@]}"; do
    if [ ! -f "$img" ]; then
        missingImages+=("$img")
    fi
done

# Check if any images are missing
if [ ${#missingImages[@]} -ne 0 ]; then
    echo "Missing images: ${missingImages[*]}"
    echo
    echo "Some required images are missing. Do you want to continue anyway?"
    echo 'Type "yes" to continue.'
    read -rp "" continue
    if [ "$continue" != "yes" ]; then
        read -rp "Press any key to exit the script..." -n1 -s
        exit
    fi
fi

echo "Starting the flashing process..."
# Flash preloader image
if [ -f "preloader_xaga.bin" ]; then
    "$fastboot" flash preloader1 preloader_xaga.bin
    "$fastboot" flash preloader2 preloader_xaga.bin
fi

for img in "${requiredImages[@]}"; do
    "$fastboot" flash "${img%.*}_a" "$img"
done

# Flash super image
if [ -f "super.img" ]; then
    "$fastboot" flash super super.img
fi

"$fastboot" set_active a
echo
echo "Flashing process completed."
echo
read -rp "Press enter to reboot." -n1 -s
"$fastboot" reboot
sleep 5
exit
